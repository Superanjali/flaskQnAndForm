# -*- coding: utf-8 -*-
"""
Created on Sat Jul 14 12:46:25 2018

@author: Sophia
"""

state = 2
wanted = 'g Q3'
res = 'g Q' + str(state + 1)